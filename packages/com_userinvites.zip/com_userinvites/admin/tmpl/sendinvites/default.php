<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_userinvites
 *
 * @copyright   Copyright (C) NPEU 2024.
 * @license     MIT License; see LICENSE.md
 */

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.formvalidator');

/*$global_edit_fields = array(
    'id',
    'parent',
    'parent_id',
    'enabled',
    'category',
    'catid',
    'featured',
    'sticky',
    'access',
    'language',
    'tags',
    'note',
    'version_note'
);*/

$app = Factory::getApplication();
$input = $app->input;
$params         = ComponentHelper::getParams($input->get('option'));
$email_template = $params->get('template');

#$this->ignore_fieldsets = array('details', 'images', 'item_associations', 'jmetadata');
$this->useCoreUI = true;

$fieldsets = $this->form->getFieldsets();
$field_types_full_width = [
    'Button',
    'Rules'
];
$field_types_no_label = [
    'Button'
];

?>

<form action="<?php echo Route::_('index.php?option=com_userinvites&amp;view=sendinvites'); ?>"
    method="post"
    name="adminForm"
    id="userinvite-form"
    class="form-validate">

    <?php #echo LayoutHelper::render('joomla.edit.title_alias', $this); ?>

    <div class="main-card">
        <?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', ['active' => 'main']); ?>

        <?php $i=0; foreach ($fieldsets as $fieldset): $i++; ?>
        <?php $form_fieldset = $this->form->getFieldset($fieldset->name); ?>

        <?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'details', Text::_($fieldset->label)); ?>

        <div class="row">
            <?php if ($fieldset->name == 'main'): ?>
            <div class="col-xl-9"><?php else: ?><div class="col-12"><?php endif; ?>
                <?php $hidden_fields = []; foreach($form_fieldset as $field): /*if(!in_array($field->fieldname, $global_edit_fields)):*/ ?>

                <?php if ($field->name == 'jform[email_body]'){
                    $field->setValue($email_template);
                } ?>

                <?php if($field->type == 'Hidden'){$hidden_fields[] = $field->input; continue;} ?>
                <?php if(!empty($field->getAttribute('hiddenLabel'))){ echo $field->input; continue; } ?>

                <div class="control-group">
                    <?php if (!in_array($field->type, $field_types_no_label)): ?>
                    <div class="control-label">
                        <?php echo Text::_($field->label); ?>
                    </div>
                    <?php endif; ?>
                    <div class="controls"<?php if (in_array($field->type, $field_types_full_width)): ?> style="flex-basis:100%;"<?php endif; ?>>

                        <?php echo $field->input; ?>

                        <?php if ($field->description != ''): ?>
                        <div id="<?php echo $field->id; ?>-desc">
                            <small class="form-text"><?php echo Text::_($field->description); ?></small>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php /*endif;*/ endforeach; ?>

            <?php if ($fieldset->name == 'main'): ?>
            </div>
            <div class="col-xl-3">
                <?php echo LayoutHelper::render('joomla.edit.global', $this); ?>
            <?php endif; ?>
            </div>

        </div>
        <?php echo HTMLHelper::_('uitab.endTab'); ?>
        <?php endforeach; ?>

        <?php echo HTMLHelper::_('uitab.endTabSet'); ?>
    </div>
    <?php echo implode("\n", $hidden_fields); ?>
    <input type="hidden" name="task" value="userinvite.edit" />
    <?php echo HTMLHelper::_('form.token'); ?>
</form>